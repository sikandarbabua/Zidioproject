
export class category {
     constructor(id, name) {
        this.id = id;
        this.name = name;
        
        
    }

}