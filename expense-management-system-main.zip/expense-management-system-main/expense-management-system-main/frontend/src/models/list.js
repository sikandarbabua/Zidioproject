export class List{

    constructor(name) {
        this.name=name;
       

        
    }

   
}