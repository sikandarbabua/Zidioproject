export class Unit{

    constructor(id, name) {
        this.id=id;
        this.name = name;

        
    }

   
}