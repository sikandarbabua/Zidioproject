export class Expense {

    constructor(id, name,recipt_image, total_cost, category) {
        this.id = id;
        this.name = name;
        this.receipt_image = recipt_image;
        this.total_cost = total_cost;
        this.category = category;
        
    }
}