export class Wallet {

    constructor(id, name, description, walletCategory) {
        this.id = id;
        this.name = name;
        this.description = description;
        this.walletCategory = walletCategory;
        
    }
}