export class ListHolder{

    constructor(list, listDetailList) {
        this.list=list;
        this.listDetailList = listDetailList;

        
    }

   
}