export class editWalletHolder{

    constructor(id,name, walletCategory, description) {
        this.id = id;
        this.name=name;
        this.walletCategory = walletCategory;
        this.description=description;
        
    }

   
}