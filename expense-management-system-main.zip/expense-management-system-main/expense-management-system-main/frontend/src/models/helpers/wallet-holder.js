export class WalletHolder{

    constructor(wallet, userList) {
        this.wallet=wallet;
        this.userList = userList;

        
    }

   
}