export class ExpenseHolder{

    constructor(expense, userList) {
        this.expense=expense;
        this.userList = userList;

        
    }

   
}