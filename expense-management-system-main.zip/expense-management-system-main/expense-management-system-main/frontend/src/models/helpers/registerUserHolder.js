export class RegisterUserHolder {

    constructor(user,confirmPassword) {
        this.user = user;
        this.confirmPassword = confirmPassword;
     
    }
}