export class ListDetail{

    constructor(name,quantity,unit) {
        this.name=name;
        this.quantity = quantity;
        this.unit = unit;

        
    }

   
}