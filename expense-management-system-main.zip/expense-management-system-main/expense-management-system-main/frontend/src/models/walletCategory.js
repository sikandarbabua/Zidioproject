import React from 'react'
import axio from 'axios'

export class WalletCategory {
     constructor(id, name) {
        this.id = id;
        this.name = name;
        
        
    }

}