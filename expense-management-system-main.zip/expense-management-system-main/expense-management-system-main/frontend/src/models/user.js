export class User {

    constructor(id, login, email, password, confirmPassword) {
        this.id = id;
        this.login = login;
        this.email = email;
        this.password = password;
        this.confirmPassword = confirmPassword;
     
    }
}