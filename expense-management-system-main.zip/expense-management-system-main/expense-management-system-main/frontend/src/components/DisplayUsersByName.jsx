import React, { Component } from 'react';

class DisplayUsersByName extends Component {
    render() {
        return (
            <div className="container">
                    <li>User1</li>
                    <li>User2</li>
                    <li>User3</li>              
            </div>
        );
    }
}

export default DisplayUsersByName;