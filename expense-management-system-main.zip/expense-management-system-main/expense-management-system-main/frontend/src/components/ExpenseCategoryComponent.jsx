import React, { Component } from 'react';

class ExpenseCategoryComponent extends Component {
    render() {
        return (
            <div className="box-subcontent-2">
                <h5 className="left-content label-text">Kategoria:</h5>
                #tutaj wyświetlone będą kategorie
            </div>
        );
    }
}

export default ExpenseCategoryComponent;