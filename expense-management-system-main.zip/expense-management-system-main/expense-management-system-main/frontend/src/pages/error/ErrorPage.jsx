import React, { Component } from 'react';

function ErrorPage() {
   
        return (
            <div>
                Kurza twarz!
            </div>
        );
    
}

export default ErrorPage;