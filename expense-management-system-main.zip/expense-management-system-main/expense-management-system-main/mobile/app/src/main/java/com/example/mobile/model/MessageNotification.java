package com.example.mobile.model;

public class MessageNotification {
}
