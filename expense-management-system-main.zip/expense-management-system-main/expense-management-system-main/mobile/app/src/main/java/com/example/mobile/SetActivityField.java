package com.example.mobile;

import com.example.mobile.model.Unit;

public interface SetActivityField {
    void editProduct(String nameProduct, String quantityProduct, Unit unit, int id);
}
